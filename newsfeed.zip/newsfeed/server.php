<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$dataFile = __DIR__ . '/posts.json';
$accountsFile = __DIR__ . '/accounts.json';

function loadPosts($file) {
    if (!file_exists($file)) return [];
    $data = file_get_contents($file);
    return json_decode($data, true) ?? [];
}

function savePosts($file, $posts) {
    file_put_contents($file, json_encode($posts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function loadAccounts($file) {
    if (!file_exists($file)) return [];
    $data = file_get_contents($file);
    return json_decode($data, true) ?? [];
}

function saveAccounts($file, $accounts) {
    file_put_contents($file, json_encode($accounts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function generateKey() {
    return bin2hex(random_bytes(16));
}

$action = $_GET['action'] ?? '';

switch ($action) {

    case 'get_posts':
        $posts = loadPosts($dataFile);
        usort($posts, fn($a, $b) => $b['timestamp'] - $a['timestamp']);
        echo json_encode(['success' => true, 'posts' => $posts]);
        break;

    case 'publish':
        $input = json_decode(file_get_contents('php://input'), true);
        $title = trim($input['title'] ?? '');
        $decision = trim($input['decision'] ?? '');
        $author = trim($input['author'] ?? '');
        $key = trim($input['key'] ?? '');

        if (!$title || !$decision || !$author || !$key) {
            echo json_encode(['success' => false, 'error' => 'Campos obrigatórios faltando']);
            break;
        }

        // Validate key
        $accounts = loadAccounts($accountsFile);
        $validAccount = null;
        foreach ($accounts as $acc) {
            if ($acc['name'] === $author && $acc['key'] === $key) {
                $validAccount = $acc;
                break;
            }
        }

        if (!$validAccount) {
            echo json_encode(['success' => false, 'error' => 'Chave inválida para esta conta']);
            break;
        }

        $posts = loadPosts($dataFile);
        $post = [
            'id' => uniqid(),
            'title' => $title,
            'decision' => $decision,
            'author' => $author,
            'timestamp' => time(),
            'date' => date('d/m/Y H:i')
        ];
        $posts[] = $post;
        savePosts($dataFile, $posts);
        echo json_encode(['success' => true, 'post' => $post]);
        break;

    case 'delete_post':
        $input = json_decode(file_get_contents('php://input'), true);
        $postId = $input['id'] ?? '';
        $key = $input['key'] ?? '';
        $author = $input['author'] ?? '';

        $accounts = loadAccounts($accountsFile);
        $validAccount = null;
        foreach ($accounts as $acc) {
            if ($acc['name'] === $author && $acc['key'] === $key) {
                $validAccount = $acc;
                break;
            }
        }

        if (!$validAccount) {
            echo json_encode(['success' => false, 'error' => 'Não autorizado']);
            break;
        }

        $posts = loadPosts($dataFile);
        $posts = array_filter($posts, fn($p) => !($p['id'] === $postId && $p['author'] === $author));
        savePosts($dataFile, array_values($posts));
        echo json_encode(['success' => true]);
        break;

    case 'create_account':
        $input = json_decode(file_get_contents('php://input'), true);
        $name = trim($input['name'] ?? '');

        if (!$name || strlen($name) < 3) {
            echo json_encode(['success' => false, 'error' => 'Nome inválido (mínimo 3 caracteres)']);
            break;
        }

        $accounts = loadAccounts($accountsFile);
        foreach ($accounts as $acc) {
            if (strtolower($acc['name']) === strtolower($name)) {
                echo json_encode(['success' => false, 'error' => 'Nome já em uso']);
                break 2;
            }
        }

        $key = generateKey();
        $accounts[] = ['name' => $name, 'key' => $key, 'created' => date('d/m/Y')];
        saveAccounts($accountsFile, $accounts);
        echo json_encode(['success' => true, 'name' => $name, 'key' => $key]);
        break;

    case 'login':
        $input = json_decode(file_get_contents('php://input'), true);
        $key = trim($input['key'] ?? '');

        if (!$key) {
            echo json_encode(['success' => false, 'error' => 'Chave obrigatória']);
            break;
        }

        $accounts = loadAccounts($accountsFile);
        foreach ($accounts as $acc) {
            if ($acc['key'] === $key) {
                echo json_encode(['success' => true, 'name' => $acc['name'], 'key' => $acc['key']]);
                break 2;
            }
        }

        echo json_encode(['success' => false, 'error' => 'Chave inválida']);
        break;

    case 'get_user_posts':
        $name = $_GET['name'] ?? '';
        $posts = loadPosts($dataFile);
        $userPosts = array_filter($posts, fn($p) => $p['author'] === $name);
        usort($userPosts, fn($a, $b) => $b['timestamp'] - $a['timestamp']);
        echo json_encode(['success' => true, 'posts' => array_values($userPosts)]);
        break;

    default:
        echo json_encode(['success' => false, 'error' => 'Ação desconhecida']);
}
?>
