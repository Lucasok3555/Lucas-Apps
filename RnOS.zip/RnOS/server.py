import socket
import json
import os
import sys
import io
import importlib.util
from datetime import datetime
import threading

class CloudOSServer:
    def __init__(self, host='0.0.0.0', port=9999, system_name="RnOS"):
        self.host = host
        self.port = port
        self.system_name = system_name
        self.commands_dir = "comandos"
        self.create_commands_directory()
        
    def create_commands_directory(self):
        """Cria o diretório de comandos se não existir"""
        if not os.path.exists(self.commands_dir):
            os.makedirs(self.commands_dir)
            print(f"[SERVIDOR] Diretório '{self.commands_dir}' criado")
            self.create_default_commands()
        
    def create_default_commands(self):
        """Cria comandos padrão do sistema"""
        # Comando: ajuda
        with open(f"{self.commands_dir}/ajuda.py", "w", encoding="utf-8") as f:
            f.write('''def executar(args):
    """Mostra a lista de comandos disponíveis"""
    import os
    comandos = []
    for arquivo in os.listdir("comandos"):
        if arquivo.endswith(".py"):
            comandos.append(arquivo[:-3])
    
    return f"Comandos disponíveis:\\n" + "\\n".join(f"  • {cmd}" for cmd in sorted(comandos))
''')
        
        # Comando: info
        with open(f"{self.commands_dir}/info.py", "w", encoding="utf-8") as f:
            f.write('''def executar(args):
    """Mostra informações do sistema"""
    import platform
    info = []
    info.append(f"Sistema Operacional: {platform.system()}")
    info.append(f"Versão: {platform.release()}")
    info.append(f"Python: {platform.python_version()}")
    info.append(f"Processador: {platform.processor()}")
    return "\\n".join(info)
''')
        
        # Comando: echo
        with open(f"{self.commands_dir}/echo.py", "w", encoding="utf-8") as f:
            f.write('''def executar(args):
    """Retorna o texto fornecido"""
    return " ".join(args) if args else "echo: texto não fornecido"
''')
        
        # Comando: calc
        with open(f"{self.commands_dir}/calc.py", "w", encoding="utf-8") as f:
            f.write('''def executar(args):
    """Calculadora simples"""
    if not args:
        return "calc: forneça uma expressão (ex: calc 2 + 2)"
    try:
        expr = " ".join(args)
        # Permite apenas operações matemáticas seguras
        resultado = eval(expr, {"__builtins__": {}}, {})
        return f"{expr} = {resultado}"
    except Exception as e:
        return f"Erro: {str(e)}"
''')
        
        # Comando: data
        with open(f"{self.commands_dir}/data.py", "w", encoding="utf-8") as f:
            f.write('''def executar(args):
    """Mostra data e hora atual do servidor"""
    from datetime import datetime
    agora = datetime.now()
    return agora.strftime("Data: %d/%m/%Y\\nHora: %H:%M:%S")
''')
        
        # Comando: listar
        with open(f"{self.commands_dir}/listar.py", "w", encoding="utf-8") as f:
            f.write('''def executar(args):
    """Lista arquivos e diretórios"""
    import os
    try:
        caminho = args[0] if args else "."
        itens = os.listdir(caminho)
        if not itens:
            return "Diretório vazio"
        return "\\n".join(sorted(itens))
    except Exception as e:
        return f"Erro: {str(e)}"
''')
        
        print("[SERVIDOR] Comandos padrão criados")
    
    def get_metadata(self):
        """Retorna metadados do sistema"""
        return {
            "nome_sistema": self.system_name,
            "data_hora": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "online"
        }
    
    def list_commands(self):
        """Lista todos os comandos disponíveis"""
        comandos = []
        for arquivo in os.listdir(self.commands_dir):
            if arquivo.endswith(".py"):
                comandos.append(arquivo[:-3])  # Remove .py
        return comandos
    
    def execute_command(self, comando, args):
        """Executa um comando Python do diretório de comandos"""
        caminho_comando = os.path.join(self.commands_dir, f"{comando}.py")
        
        if not os.path.exists(caminho_comando):
            return f"Erro: comando '{comando}' não encontrado"
        
        # Captura stdout e stderr
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        stdout_capture = io.StringIO()
        stderr_capture = io.StringIO()
        
        try:
            # Redireciona stdout e stderr
            sys.stdout = stdout_capture
            sys.stderr = stderr_capture
            
            # Carrega o módulo dinamicamente
            spec = importlib.util.spec_from_file_location(comando, caminho_comando)
            modulo = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(modulo)
            
            # Executa a função 'executar' do comando
            if hasattr(modulo, 'executar'):
                resultado = modulo.executar(args)
                
                # Captura qualquer print() feito dentro do comando
                stdout_output = stdout_capture.getvalue()
                stderr_output = stderr_capture.getvalue()
                
                # Combina resultado com outputs capturados
                output_parts = []
                if stdout_output:
                    output_parts.append(stdout_output.strip())
                if stderr_output:
                    output_parts.append(stderr_output.strip())
                if resultado:
                    output_parts.append(str(resultado))
                
                return "\n".join(output_parts) if output_parts else ""
            else:
                return f"Erro: comando '{comando}' não possui função executar()"
                
        except Exception as e:
            stderr_output = stderr_capture.getvalue()
            if stderr_output:
                return f"Erro ao executar '{comando}':\n{stderr_output}\n{str(e)}"
            return f"Erro ao executar '{comando}': {str(e)}"
        finally:
            # Restaura stdout e stderr
            sys.stdout = old_stdout
            sys.stderr = old_stderr
    
    def handle_client(self, conn, addr):
        """Gerencia a conexão com um cliente"""
        print(f"[CONEXÃO] Cliente conectado: {addr}")
        
        try:
            # Envia metadados ao conectar
            metadata = self.get_metadata()
            conn.send(json.dumps(metadata).encode('utf-8'))
            
            while True:
                # Recebe comando do cliente
                data = conn.recv(4096).decode('utf-8')
                if not data or data == "sair":
                    break
                
                # Parse do comando
                partes = data.strip().split()
                if not partes:
                    conn.send("".encode('utf-8'))
                    continue
                
                comando = partes[0]
                args = partes[1:] if len(partes) > 1 else []
                
                # Log apenas no servidor (não envia para cliente)
                print(f"[COMANDO] {addr} executou: {data.strip()}")
                
                # Executa comando
                resultado = self.execute_command(comando, args)
                
                # Envia resultado APENAS para o cliente
                conn.send(resultado.encode('utf-8'))
                
        except Exception as e:
            print(f"[ERRO] {addr}: {e}")
        finally:
            conn.close()
            print(f"[DESCONEXÃO] Cliente desconectado: {addr}")
    
    def start(self):
        """Inicia o servidor"""
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((self.host, self.port))
        server.listen(5)
        
        print(f"[SERVIDOR] {self.system_name} iniciado em {self.host}:{self.port}")
        print(f"[SERVIDOR] Comandos disponíveis: {', '.join(self.list_commands())}")
        print(f"[SERVIDOR] Aguardando conexões...")
        
        try:
            while True:
                conn, addr = server.accept()
                thread = threading.Thread(target=self.handle_client, args=(conn, addr))
                thread.start()
        except KeyboardInterrupt:
            print("\n[SERVIDOR] Encerrando...")
            server.close()

if __name__ == "__main__":
    servidor = CloudOSServer(host='0.0.0.0', port=9999, system_name="CloudOS v1.0")
    servidor.start()