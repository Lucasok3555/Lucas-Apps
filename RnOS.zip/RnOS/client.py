import socket
import json

class CloudOSClient:
    def __init__(self):
        self.socket = None
        self.connected = False
        self.server_info = {}
        
    def conectar(self, host, port=9999):
        """Conecta ao servidor RnOS"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((host, port))
            
            # Recebe metadados do servidor
            metadata = self.socket.recv(4096).decode('utf-8')
            self.server_info = json.loads(metadata)
            
            self.connected = True
            self.exibir_banner()
            
            return True
            
        except Exception as e:
            print(f"Erro ao conectar: {e}")
            return False
    
    def exibir_banner(self):
        """Exibe banner de conexão com informações do servidor"""
        print(f"\n{'='*60}")
        print(f"CONECTADO AO SERVIDOR")
        print(f"{'='*60}")
        print(f"Sistema: {self.server_info.get('nome_sistema', 'N/A')}")
        print(f"Data/Hora: {self.server_info.get('data_hora', 'N/A')}")
        print(f"Status: {self.server_info.get('status', 'N/A')}")
        print(f"{'='*60}\n")
        print("Digite 'ajuda' para ver os comandos disponíveis")
        print("Digite 'sair' para desconectar\n")
    
    def enviar_comando(self, comando):
        """Envia um comando para o servidor e recebe o resultado"""
        if not self.connected:
            return "Erro: não conectado ao servidor"
        
        try:
            # Envia comando
            self.socket.send(comando.encode('utf-8'))
            
            # Recebe resposta (aumenta buffer para respostas grandes)
            resposta = self.socket.recv(8192).decode('utf-8')
            return resposta
            
        except Exception as e:
            return f"Erro ao enviar comando: {e}"
    
    def desconectar(self):
        """Desconecta do servidor"""
        if self.socket:
            try:
                self.socket.send("sair".encode('utf-8'))
                self.socket.close()
            except:
                pass
        self.connected = False
        print("\n" + "="*60)
        print("Desconectado do servidor")
        print("="*60)
    
    def terminal(self):
        """Interface de terminal para interação com o servidor"""
        while self.connected:
            try:
                # Prompt customizado com nome do sistema
                sistema = self.server_info.get('nome_sistema', 'CloudOS')
                comando = input(f"\n{sistema}> ").strip()
                
                if not comando:
                    continue
                
                if comando.lower() == "sair":
                    self.desconectar()
                    break
                
                # Envia comando e exibe resultado
                resultado = self.enviar_comando(comando)
                
                # Exibe resultado formatado
                if resultado:
                    print(f"\n{resultado}")
                
            except KeyboardInterrupt:
                print("\n")
                self.desconectar()
                break
            except Exception as e:
                print(f"\nErro: {e}")
                break

def main():
    print("="*60)
    print(" "*15 + "CLIENTE CloudOS")
    print("="*60)
    
    cliente = CloudOSClient()
    
    # Solicita endereço do servidor
    print("\n>>> Conexão ao Servidor <<<")
    host = input("\nEndereço do servidor (ex: localhost ou 192.168.1.100): ").strip()
    
    if not host:
        host = "localhost"
        print(f"Usando endereço padrão: {host}")
    
    porta_input = input("Porta (padrão: 9999): ").strip()
    porta = int(porta_input) if porta_input else 9999
    
    # Tenta conectar
    print(f"\nConectando a {host}:{porta}...")
    
    if cliente.conectar(host, porta):
        # Inicia terminal
        cliente.terminal()
    else:
        print("\n" + "="*60)
        print("FALHA NA CONEXÃO")
        print("="*60)
        print("\nVerifique se:")
        print("  1. O servidor está rodando")
        print("  2. O endereço e porta estão corretos")
        print("  3. Não há firewall bloqueando a conexão")

if __name__ == "__main__":
    main()